﻿namespace Cs_Risk_Assessment.ViewModels
{
	public class AssessmentViewModel
	{
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int AssetsCount { get; set; }
    }
}
