﻿namespace Cs_Risk_Assessment.ViewModels
{
	public class AssessmentViewModel
	{
        public string Name { get; set; }
        public int AssetsCount { get; set; }
    }
}
