﻿namespace Cs_Risk_Assessment.ViewModels
{
	public record LikehoodAndImpactDto(string Vulnerability, string Likelihood, string Impact);
}
